Robotik v2 - Android Project

1. Buka project ini di Android Studio.
2. Jalankan Gradle Sync.
3. Build APK debug via menu: Build -> Build APK(s).
4. Install app-debug.apk ke HP.

📱 Fitur baru:
- Settings screen (nama panggilan, API key, status aktif).
- Data tersimpan di SharedPreferences.
- API key opsional, bisa kosong jika offline.
