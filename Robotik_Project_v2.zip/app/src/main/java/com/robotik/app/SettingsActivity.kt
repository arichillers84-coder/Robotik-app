package com.robotik.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.robotik.app.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences("robotik_prefs", Context.MODE_PRIVATE)

        // Load saved values
        binding.editApiKey.setText(prefs.getString("api_key", ""))
        binding.editNickname.setText(prefs.getString("nickname", "Sayang"))
        binding.switchActive.isChecked = prefs.getBoolean("active", true)

        // Save button
        binding.btnSave.setOnClickListener {
            prefs.edit()
                .putString("api_key", binding.editApiKey.text.toString())
                .putString("nickname", binding.editNickname.text.toString())
                .putBoolean("active", binding.switchActive.isChecked)
                .apply()
            finish()
        }
    }
}
